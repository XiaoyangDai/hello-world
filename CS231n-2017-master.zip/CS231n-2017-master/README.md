# CS231n - Spring 2017

These are my solutions to the CS231n Spring 2017 course from Stanford University http://cs231n.github.io/. 
I worked through all the assignments to improve my Python skills as well as my understanding of deep learning.

## Completed
* Assignment 1
* Assignment 2 (PyTorch and Tensorflow)
* Assignment 3 (PyTorch and Tensorflow)

## Future work
* Extra credit tasks


## Questions

If you have questions about anything I'll be happy to try and answer them just post it as an issue and I'll try to respond when I can.
