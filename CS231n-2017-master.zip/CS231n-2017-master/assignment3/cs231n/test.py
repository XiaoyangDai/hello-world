# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 10:44:10 2018

@author: 10704
"""
'''
    x_Wx = np.dot(x, Wx)
    prev_h_Wh = np.dot(prev_h, Wh)

    # Calculate next hidden state = tanh(x*Wx + prev_H*Wh + b)
    next_h = np.tanh(x_Wx + prev_h_Wh + b)

    cache = (Wx, Wh, b, x, prev_h, next_h)




    # Grab our cached variables needed for backprop.
    Wx, Wh, b, x, prev_h, next_h = cache

    # Backprop dnext_h through the tanh function first, derivative of tanh is 1-tanh^2.
    dtanh = (1 - np.square(next_h)) * dnext_h

    # Backprop dtanh to calculate the other derivates (no complicated derivatives here).
    db = np.sum(dtanh, axis=0)
    dWh = np.dot(prev_h.T, dtanh)
    dprev_h = np.dot(dtanh, Wh.T)
    dWx = np.dot(x.T, dtanh)
    dx = np.dot(dtanh, Wx.T)
'''


'''
    N, T, D = x.shape
    N, H = h0.shape

    # Initialise h for holding our calculated hidden states.
    h = np.zeros([N, T, H])
    cache = []

    # Our initial hidden state
    prev_h = h0

    # RNN forward for T time steps.
    for t_step in range(T):
        cur_x = x[:, t_step, :]
        prev_h, cache_temp = rnn_step_forward(cur_x, prev_h, Wx, Wh, b)
        h[:, t_step, :] = prev_h
        cache.append(cache_temp)
'''
'''
        # FORWARD PASS.
        # Transform CNN image feature to be the initial hidden state.
        inital_hidden_state, cache_initial = affine_forward(features, W_proj, b_proj)

        # Embed the input word captions.
        embedded_captions, cache_word_embedding = word_embedding_forward(captions_in, W_embed)

        # Vanilla RNN or LSTM forward pass.
        if self.cell_type == 'rnn':
            rnn_outputs, cache_rnn = rnn_forward(embedded_captions, inital_hidden_state, Wx, Wh, b)
        elif self.cell_type == 'lstm':
            rnn_outputs, cache_rnn = lstm_forward(embedded_captions, inital_hidden_state, Wx, Wh, b)

        # Scores and loss.
        scores, cache_scores = temporal_affine_forward(rnn_outputs, W_vocab, b_vocab)
        loss, dsoftmax = temporal_softmax_loss(scores, captions_out, mask)

        # BACKWARD PASS.
        # Backprop dsoftmax to calculate gradient for W_vocab, b_vocab.
        dscores, dW_vocab, db_vocab = temporal_affine_backward(dsoftmax, cache_scores)
        grads['W_vocab'], grads['b_vocab'] = dW_vocab, db_vocab

        # Backprop dscores through the RNN module calculating all gradients.
        if self.cell_type == 'rnn':
            dx, dh0, dWx, dWh, db = rnn_backward(dscores, cache_rnn)
            grads['b'], grads['Wh'], grads['Wx'] = db, dWh, dWx
        elif self.cell_type == 'lstm':
            dx, dh0, dWx, dWh, db = lstm_backward(dscores, cache_rnn)
            grads['b'], grads['Wh'], grads['Wx'] = db, dWh, dWx

        # Backprop dx to get gradient for word embedding weights.
        dW_embed = word_embedding_backward(dx, cache_word_embedding)
        grads['W_embed'] = dW_embed

        # Backprop dh0 to get gradient for feature projection weights.
        dx_initial, dW_proj, db_proj = affine_backward(dh0, cache_initial)
        grads['W_proj'], grads['b_proj'] = dW_proj, db_proj

'''
'''

    # Get H for slicing up activation vector A.
    H = np.shape(prev_h)[1]

    # Calculate activation vector A=x*Wx + prev_h*Wh + b.
    a_vector = np.dot(x, Wx) + np.dot(prev_h, Wh) + b

    # Slice activation vector to get the 4 parts of it: input/forget/output/block.
    a_i = a_vector[:, 0:H]
    a_f = a_vector[:, H:2*H]
    a_o = a_vector[:, 2*H:3*H]
    a_g = a_vector[:, 3*H:]

    # Activation functions applied to our 4 gates.
    input_gate = sigmoid(a_i)
    forget_gate = sigmoid(a_f)
    output_gate = sigmoid(a_o)
    block_input = np.tanh(a_g)

    # Calculate next cell state.
    next_c = (forget_gate * prev_c) + (input_gate * block_input)

    # Calculate next hidden state.
    next_h = output_gate * np.tanh(next_c)

    # Cache variables needed for backprop.
    cache = (x, Wx, Wh, b, prev_h, prev_c, input_gate, forget_gate, output_gate, block_input, next_c, next_h)
'''
'''
    # Reference for LSTM graph
    # http://practicalcryptography.com/miscellaneous/machine-learning/graphically-determining-backpropagation-equations/

    x, Wx, Wh, b, prev_h, prev_c, input_gate, forget_gate, output_gate, block_input, next_c, next_h = cache

    # Backprop dnext_h through the multiply gate.
    dh_tanh = dnext_h * output_gate
    da_o_partial = dnext_h * np.tanh(next_c)

    # Backprop dh_tanh through the tanh function.
    dtanh = dh_tanh * (1 - np.square(np.tanh(next_c)))

    # We add dnext_c and dtanh as during forward pass we split activation (gradients add up at forks).
    dtanh_dc = (dnext_c + dtanh)

    # Backprop dtanh_dc to calculate dprev_c.
    dprev_c = dtanh_dc * forget_gate

    # Backprop dtanh_dc towards each gate.
    da_i_partial = dtanh_dc * block_input
    da_g_partial = dtanh_dc * input_gate
    da_f_partial = dtanh_dc * prev_c

    # Backprop through gate activation functions to calculate gate derivatives.
    da_i = input_gate*(1-input_gate) * da_i_partial
    da_f = forget_gate*(1-forget_gate) * da_f_partial
    da_o = output_gate*(1-output_gate) * da_o_partial
    da_g = (1-np.square(block_input)) * da_g_partial

    # Concatenate back up our 4 gate derivatives to get da_vector.
    da_vector = np.concatenate((da_i, da_f, da_o, da_g), axis=1)

    # Backprop da_vector to get remaining gradients.
    db = np.sum(da_vector, axis=0)
    dx = np.dot(da_vector, Wx.T)
    dWx = np.dot(x.T, da_vector)
    dprev_h = np.dot(da_vector, Wh.T)
    dWh = np.dot(prev_h.T, da_vector)

'''

'''
    N, T, D = x.shape
    N, H = h0.shape

    cache = []
    h = np.zeros([N, T, H])

    # Set initial h and c states.
    prev_h = h0
    prev_c = np.zeros_like(h0)

    for time_step in range(T):
        prev_h, prev_c, cache_temp = lstm_step_forward(x[:,time_step,:], prev_h, prev_c, Wx, Wh, b)
        h[:, time_step, :] = prev_h  # Store the hidden state for this time step.
        cache.append(cache_temp)


'''
'''

    x, Wx, Wh, b, prev_h, prev_c, input_gate, forget_gate, output_gate, block_input, next_c, next_h = cache[0]

    N, T, H = dh.shape
    D, _ = Wx.shape

    dx = np.zeros([N, T, D])
    dprev_h = np.zeros_like(prev_h)
    dWx = np.zeros_like(Wx)
    dWh = np.zeros_like(Wh)
    db = np.zeros_like(b)

    # Initial gradient for cell is all zero.
    dprev_c = np.zeros_like(dprev_h)

    for time_step in reversed(range(T)):

        # Add the current timestep upstream gradient to previous calculated dh.
        cur_dh = dprev_h + dh[:,time_step,:]

        dx[:,time_step,:], dprev_h, dprev_c, dWx_temp, dWh_temp, db_temp = lstm_step_backward(cur_dh, dprev_c, cache[time_step])

        # Add gradient contributions from each time step together.
        db += db_temp
        dWh += dWh_temp
        dWx += dWx_temp

    # dh0 is the last hidden state gradient calculated.
    dh0 = dprev_h

'''
'''
# In Tensorflow we add things to our graph to run.
    
    # Calculate gradient of correct score with respect to the input image.
    dX = tf.gradients(correct_scores, model.image)
    
    # We take absolute values, get max along channels and remove singleton dimension.
    saliency_abs = tf.abs(dX)
    saliency_max = tf.reduce_max(saliency_abs, axis=4)
    saliency_squeeze = tf.squeeze(saliency_max)
    
    # Run our graph.
    saliency = sess.run(saliency_squeeze, feed_dict={model.image:X, model.labels:y})
'''

'''
    # Get the scores of forward pass.
    scores = model.classifier
    
    # Backprop to get gradient of target score with respect to input image.
    gradient = tf.gradients(scores[:,target_y], model.image)
    
    # This line is for removing extra single dimension that is added.
    gradient = tf.squeeze(gradient, [0])

    norm_gradient = tf.norm(gradient)    
    dX = learning_rate * gradient / norm_gradient
    
    while True:
        # Run our graph to get the image update and the current scores.
        gradient_step, scores_out = sess.run([dX, scores], feed_dict={model.image:X_fooling})
        
        # Stop iterating once we have fooled our network.
        if np.argmax(scores_out) == target_y:
            return X_fooling
        
        # Else we update the image.
        X_fooling += gradient_step
'''

import tensorflow as tf

with tf.Graph().as_default():
  a = tf.Variable(1)
  a_op = tf.assign(a, tf.add(a,1))
  with tf.Session() as sess:
    #sess.run(tf.global_variables_initializer())
    print (a.eval())
    print (sess.run(a))

    print (sess.run(a_op))
    
    print (sess.run(a))
    print (a.eval())
'''
import tensorflow as tf
tf.reset_default_graph()
a = tf.Variable(1, name="a")
b = tf.Variable(1, name="b")

with tf.variable_scope('myscope') as m_scope:
    op= tf.assign(a, tf.add(a,b))
    myscope_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=m_scope.name)

with tf.Session() as sess:
    sess.run(tf.variables_initializer([a,b]+myscope_vars))
    print(a.eval())
    sess.run(op)
    print(a.eval())
    sess.run(myscope_vars)
    print(myscope_vars)
'''    
    
    
        